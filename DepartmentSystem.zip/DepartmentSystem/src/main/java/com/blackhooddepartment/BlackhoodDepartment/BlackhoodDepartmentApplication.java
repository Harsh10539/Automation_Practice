package com.blackhooddepartment.BlackhoodDepartment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlackhoodDepartmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlackhoodDepartmentApplication.class, args);
	}

}
