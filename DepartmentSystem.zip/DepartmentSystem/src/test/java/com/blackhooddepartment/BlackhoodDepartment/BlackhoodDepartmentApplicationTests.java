package com.blackhooddepartment.BlackhoodDepartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlackhoodDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
